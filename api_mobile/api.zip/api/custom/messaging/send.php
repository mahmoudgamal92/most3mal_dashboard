<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once './../config/dbconnect.php';

// Check for the presence of POST data
$sender_id = isset($_POST['sender_id']) ? $_POST['sender_id'] : null;
$conv_id = isset($_POST['conv_id']) ? $_POST['conv_id'] : null;
$message = isset($_POST['message']) ? $_POST['message'] : null;
$attachments = isset($_POST['attachments']) ? $_POST['attachments'] : null;
$seen = isset($_POST['seen']) ? $_POST['seen'] : null;

if ($sender_id !== null && $conv_id !== null && $message !== null && $attachments !== null && $seen !== null) {
    // Use prepared statements to prevent SQL injection
    $stmt = $con->prepare("INSERT INTO messages (sender_id, conv_id, msg, attachment, seen) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $sender_id, $conv_id, $message, $attachments, $seen);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("success" => true));
    } else {
        // Log the MySQL error
        error_log("MySQL Error: " . $stmt->error);
        http_response_code(409);
        echo json_encode(array("success" => false, "error" => "Conflict"));
    }

    $stmt->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(array("success" => false, "error" => "Invalid or missing parameters"));
}
?>