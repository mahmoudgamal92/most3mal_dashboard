<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once './../../config/dbconnect.php';

if(isset($_POST['action']))
{
    $action = $_POST['action'];

    if($action == 'update')
    {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $details = $_POST['details'];
        $price = $_POST['price'];
        $address = $_POST['address'];
        $coords = $_POST['coords'];

        $cmd = "update ads set title = '$title', details = '$details' , price = '$price' , address =  '$address' , coords = '$coords' where id = '$id'";
        $res = mysqli_query($con,$cmd);
        if($res){
            
        echo json_encode(array(
        "success" => true,
        "message" => "ad Have been Updated Successfully"
        ));
        exit();
        
        }
        else {
             echo json_encode(array(
        "success" => false,
        "message" => mysqli_error($con)
        ));
        exit();
        }
    }
}
?>